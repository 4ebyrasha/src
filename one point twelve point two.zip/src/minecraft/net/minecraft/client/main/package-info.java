@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.client.main;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;