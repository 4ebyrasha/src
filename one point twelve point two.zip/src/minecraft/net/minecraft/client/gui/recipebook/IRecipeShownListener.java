package net.minecraft.client.gui.recipebook;

public interface IRecipeShownListener
{
    void recipesUpdated();

    GuiRecipeBook func_194310_f();
}
