@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.block;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;